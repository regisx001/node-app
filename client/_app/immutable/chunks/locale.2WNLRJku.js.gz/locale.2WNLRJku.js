function i(t){return window.getComputedStyle(t).getPropertyValue("direction")}export{i as g};
