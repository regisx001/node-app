import{b as a,E as i,c as n,d as p}from"./runtime.Dn8xTbO9.js";function o(t,f,...r){var e,s;a(()=>{e!==(e=t())&&(s&&(p(s),s=null),e&&(s=n(()=>e(f,...r))))},i)}export{o as s};
