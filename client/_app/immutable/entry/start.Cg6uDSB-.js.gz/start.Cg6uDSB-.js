import{a as t}from"../chunks/entry.BXpd0qG0.js";export{t as start};
